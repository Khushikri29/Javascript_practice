
    // 1.js console api
   //2. to print in js 
//     console.log("hello world.....");
// document.write("khushi kri")
// console.warn("warning");
// console.error("error");
//3. variables(container to store data value)
// var num1 = 2;
// var num2 = 4;
// console.log(num1+num2);
// //4.datatypes
// var Str1 = "this is a string";//string
// var Str2 = 'string';
// var Num = 29; //number
// var Marks ={  //objects
//     ravi:66,

//     khushi:99
// }
// console.log(Marks);
//  var A = true;

//  const num= -10;
