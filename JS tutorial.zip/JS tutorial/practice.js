// // // function greet(name) {
// // //   return "Hello, " + name;
// // // }
// // // console.log(greet("Khushi")); // Output: Hello, Khushi
// // // // function greet(name) {
// // // // return "hii,"+name;
// // // // }
// // // // console.log(greet("world"));


// // const findDigitCountInNumber = (n) => {
// //   if (n === 0) return 1; // Corner Case : if Number Is zero; we can consider this as 1 digit
// //   if (n < 0) { // Corner Case: If Number is Negative convert into positive 
// //     n = Math.abs(n); 
// //   }
// //   let count = 0;
// //   while (n > 0) {
// //     n = Math.floor(n / 10);
// //     count++;
// //   }
// //   return count;
// // };

// // console.log("res::Positive::", findDigitCountInNumber(123455)); // 6
// // console.log("res:::Zero:::::", findDigitCountInNumber(0)); // 1
// // console.log("res::::Negative:::::", findDigitCountInNumber(-123455)); // 6

// // const isPalindromeNumber = (n) => {
// //   if (n < 0) return false; // negative number can't be palindrome
// //   if (n < 10) return true; // single digit number is always palindrome
// //   let copyN = n;
// //   let reverse = 0;
// //   while (n > 0) {
// //     let lastDigit = n % 10;
// //     reverse = reverse * 10 + lastDigit;
// //     n = Math.floor(n / 10);
// //   }

// //   return copyN === reverse;
// // };

// // isPalindromeNumber(121);     // Output: true
// // isPalindromeNumber(-121);    // Output: false
// // isPalindromeNumber(10);      // Output: false
// // isPalindromeNumber(122345);  // Output: false
// // isPalindromeNumber(9);       // Output: true


// const user = {
//   name:"khushi",
//   address:{city:"delhi"},
//   hobby:["reading","dancing"]
// };
// const deepuser = structuredClone(user);
// deepuser.address.city = "Mumbai";
// console.log(user.address.city);