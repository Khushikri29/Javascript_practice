// // // to print node file ka naam.js

// // // const value = -10;
// // // console.log(Math.abs(value)); 

// // // const value = 10.5;
// // // console.log(Math.floor(value)); 

// // // const value = 12.8;
// // // console.log(Math.ceil(value)); 
// // // const value1 = 99.01;
// // // console.log(Math.ceil(value1)); 

// // // const value = 12.8;
// // // console.log(Math.round(value)); 
// // // const value1 = 99.01;
// // // console.log(Math.round(value1)); 

// // // console.log(Math.round(36.5)) // 37
// // // console.log(Math.round(45.4)) // 45
// // // console.log(Math.round(88.1)) // 88
// // // console.log(Math.round(74.6)) // 75

// // // console.log(Math.pow(2,3)) //8
// // // console.log(Math.pow(4,5)) // 1024
// // // console.log(Math.pow(3,2)) // 9
// // // console.log(Math.pow(10,2)) // 100

// // // let n = 123456789;
// // // let count = 0;

// // // while (n > 0) {
// // //   n = Math.floor(n / 10);
// // //   count++;
// // // }

// // // console.log(count);

// // // const number = 123456789; 

// // // const findDigitInNumber = (n) => {
// // //   let count = 0;

// // //   while (n > 0) {
// // //     n = Math.floor(n / 10);
// // //     count++;
// // //   }

// // //   return count;
// // // };

// // // console.log(findDigitInNumber(number)); 


// const number = 987456123; 

// console.log("Hii")

// const findDigitInNumber = (n) => {
//   let count = 0;
//   if (n === 0) return 1;
//   if (n < 0) {
//      n = Math.abs(n);
//   }
  
//   while (n > 0) {
//     n = Math.floor(n / 10);
//     count++;
//   }

//   return count;
// };


// const res = findDigitInNumber(number);

// console.log("Res:::", res);

// //palimdrome num

// let x = 123;
// let reversed = 0;

// while (x > 0) {
//   let lastDigit = x % 10;          // Get the last digit
//   reversed = reversed * 10 + lastDigit; // Add last digit to reversed number
//   x = Math.floor(x / 10);          // Remove the last digit from x
// }

// console.log(reversed); // Output: 321



// // let N =4;
// // for (let i=N;i>=1;i--){
// //   let spaces =" ".repeat(N-i);
// //   let star = "*".repeat(i);
// // console.log(spaces+star);
// // }
// // let n = 5;
// // for (let i = n; i >= 1; i--) {
// //     let str = "* ";
// //     console.log(str.repusing while loop
// eat(i));
// // }

// function greet(name) {
//   return "Hello, " + name;
// }
// console.log(greet("Khushi"));
